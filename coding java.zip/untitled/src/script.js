<!DOCTYPE html>

<html lang="en">

<head>

  <meta charset="UTF-8">

  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <title>Vaishnavi | Portfolio</title>

  <link rel="stylesheet" href="style.css">

</head>

<body>

  <!-- Navbar -->

  <header>

    <nav class="navbar">

      <h1 class="logo">Mathiyarasi</h1>

      <ul class="nav-links">

        <li><a href="#home">Home</a></li>

        <li><a href="#about">About</a></li>

        <li><a href="#skills">Skills</a></li>

        <li><a href="#portfolio">Portfolio</a></li>

        <li><a href="#contact">Contact</a></li>

      </ul>

    </nav>

  </header>

  <!-- Home -->

  <section id="home" class="home">

    <img src="https://via.placeholder.com/150" alt="Profile" class="profile-pic">

    <h2>Hi, I am Mathiyarasi 👋</h2>

    <p>A B.Sc. Computer Science student passionate about learning coding.</p>

  </section>

  <!-- About -->

  <section id="about" class="about">

    <h2>About Me</h2>

    <p>I have completed my schooling and I am now pursuing <b>B.Sc. Computer Science</b>. Currently, I am a student eager to learn and improve my coding skills.</p>

  </section>

  <!-- Skills -->

  <section id="skills" class="skills">

    <h2>Skills</h2>

    <div class="skills-box">

      <div class="skill">Java</div>

      <div class="skill">C</div>

      <div class="skill">C++</div>

    </div>

  </section>

  <!-- Portfolio -->

  <section id="portfolio" class="portfolio">

    <h2>Portfolio</h2>

    <p>No notable projects yet, but exciting things are coming soon! 🚀</p>

  </section>

  <!-- Contact -->

  <section id="contact" class="contact">

    <h2>Contact Me</h2>

    <p>📧 Email: <a href="mailto:rajanmathi269@gmail.com">rajanmathi269@gmail.com</a></p>

    <p>📞 Phone: 1234567891</p>

  </section>

  <!-- Footer -->

  <footer class="footer">

    <p>© 2025 Mathiyarasi | Portfolio</p>

  </footer>

  <script src="script.js"></script>

</body>

</html>